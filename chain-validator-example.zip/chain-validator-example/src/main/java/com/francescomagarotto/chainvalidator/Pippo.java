package com.francescomagarotto.chainvalidator;

public class Pippo {
    private String name;
    private String surname;

    private String apricot;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getApricot() {
        return apricot;
    }

    public void setApricot(String apricot) {
        this.apricot = apricot;
    }
}
